Installing
pip install numpy scipy scikit-learn scikit-surprise

Running
python3 hw4.py

See report for reason on using surprise
